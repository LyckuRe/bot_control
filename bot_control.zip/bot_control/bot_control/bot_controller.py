from flask import Flask, render_template_string, request, redirect, url_for
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import threading
import time

app = Flask(__name__)

htlm_template_string = """<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>TurtleBot Controller</title>
  </head>
  <body>
    <div class="container">
      <h1 class="mt-5">TurtleBot Controller Interface</h1>
      <form action="/send_commands" method="post">
        <div class="form-group">
          <label for="wait_time">Time till execution:</label>
          <input type="number" class="form-control" id="wait_time" name="wait_time" value="0">
        </div>
        <div class="form-check">
          <input type="checkbox" class="form-check-input" id="simultaneous" name="simultaneous" value="yes">
          <label class="form-check-label" for="simultaneous">Run both turtle bots at the same time</label>
        </div>
        <div class="form-check">
          <input type="checkbox" class="form-check-input" id="square_first" name="square_first" value="yes">
          <label class="form-check-label" for="square_first">Run the square turtle first (both will still run simultaneously if that option is checked)</label>
        </div>
        <div class="form-check">
          <input type="checkbox" class="form-check-input" id="repeat" name="repeat" value="no">
          <label class="form-check-label" for="repeat">Repeat the commands every two minutes</label>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Send Control Messages</button>
      </form>
    </div>
  </body>
</html>
"""

class BotController(Node):
    def __init__(self):
        super().__init__('bot_controller')
        self.publisher_turtle1 = self.create_publisher(Twist, '/turtle1/turtle1/cmd_vel', 10) # this will be the square turtle
        self.publisher_turtle2 = self.create_publisher(Twist, '/turtle2/turtle1/cmd_vel', 10) # this will be the triangle turtle
        self.lock = threading.Lock() # turn lock. for allowing waiting between turtles
        self.t1_lock = threading.Lock() # turtle1 lock
        self.t2_lock = threading.Lock() # turtle2 lock

    def publish_controls(self, simultaneous, square_first):        
        # check if simultaneous control is requested
        if simultaneous:
            print('simultaneous control requested')
            # create threads to allow for simultaneous broadcast of control signals
            t1_thread = threading.Thread(target=self.plot_square, args=(self.publisher_turtle1,))
            t2_thread = threading.Thread(target=self.plot_triangle, args=(self.publisher_turtle2,))
            t1_thread.start()
            t2_thread.start()
            
            t1_thread.join()
            t2_thread.join()
        else:
            print('single control requested')
            if square_first:
                # square turtle is blocking
                self.plot_square(self.publisher_turtle1, True)
                self.plot_triangle(self.publisher_turtle2)
            else:
                # triangle turtle is blocking
                self.plot_triangle(self.publisher_turtle2, True)
                self.plot_square(self.publisher_turtle1)
            
    def plot_square(self, publisher, blocking=False):
        print('requesting control of square turtle')
        self.t1_lock.acquire()
        if blocking:
        	self.lock.acquire()
        
        move_cmd = Twist()
        turn_cmd = Twist()
        move_cmd.linear.x = 1.0
        turn_cmd.angular.z = 1.57
        
        # square plotting
        print('plotting square...')
        for _ in range(4):
            publisher.publish(move_cmd)
            time.sleep(1)
            publisher.publish(Twist())  # Stop
            time.sleep(0.5)
            publisher.publish(turn_cmd)
            time.sleep(1)
            publisher.publish(Twist())  # Stop
            time.sleep(0.5)
        
        if blocking:
            self.lock.release()
        self.t1_lock.release()

    def plot_triangle(self, publisher, blocking=False):
        print('requesting control of triangle turtle')
        self.t2_lock.acquire()
        if blocking:
            self.lock.acquire()
    
        move_cmd = Twist()
        turn_cmd = Twist()
        move_cmd.linear.x = 1.0
        turn_cmd.angular.z = 2.09
        
        # triangle plotting
        print('plotting triangle...')
        for _ in range(3):
            publisher.publish(move_cmd)
            time.sleep(1)
            publisher.publish(Twist())  # Stop
            time.sleep(0.5)
            publisher.publish(turn_cmd)
            time.sleep(1)
            publisher.publish(Twist())  # Stop
            time.sleep(0.5)
            
        if blocking:
            self.lock.release()
        self.t2_lock.release()


@app.route('/')
def index():
    return render_template_string(htlm_template_string)

@app.route('/send_commands', methods=['POST'])
def send_commands():
    # obtain info from ui
    wait_time = int(request.form['wait_time'])
    simultaneous = 'simultaneous' in request.form
    square_first = 'square_first' in request.form
    
    # wait for specified time in seconds
    print(f'waiting {wait_time} seconds...')
    time.sleep(wait_time)
    
    repeating = True
    while repeating:
        print('publishing controls...')
        bot_controller_node.publish_controls(simultaneous, square_first)
        time.sleep(120) # two minute delay
        repeating = 'repeat' in request.form # update loop flag
    return redirect(url_for('index'))

def run_flask():
    app.run(host='0.0.0.0', port=5000)

def main():

    rclpy.init(args=None)
    global bot_controller_node
    bot_controller_node = BotController()

    flask_thread = threading.Thread(target=run_flask)
    flask_thread.start()

    rclpy.spin(bot_controller_node)

    bot_controller_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
